# Preserve youtubedl-android & Jackson JSON mapping models used for --dump-json
-keep class com.yausername.youtubedl_android.** { *; }
-keep class com.yausername.ffmpeg.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-dontwarn com.fasterxml.jackson.**

# Preserve Room entities and DAOs
-keep class com.videodownloader.app.data.local.** { *; }

# Preserve Kotlin coroutines & Hilt generated components
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keepclassmembers class * {
    @dagger.hilt.android.lifecycle.HiltViewModel <init>(...);
}
