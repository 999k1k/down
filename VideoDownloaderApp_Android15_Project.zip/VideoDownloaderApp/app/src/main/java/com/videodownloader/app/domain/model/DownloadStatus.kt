package com.videodownloader.app.domain.model

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    MERGING,
    COMPLETED,
    FAILED,
    CANCELLED
}
