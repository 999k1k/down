package com.videodownloader.app.domain.model

enum class SupportedPlatform(val displayName: String) {
    INSTAGRAM("Instagram"),
    FACEBOOK("Facebook"),
    TIKTOK("TikTok");

    companion object {
        fun detect(rawUrl: String): SupportedPlatform? {
            val normalized = rawUrl.trim().lowercase()
            if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
                return null
            }
            return when {
                normalized.contains("instagram.com") || normalized.contains("instagr.am") -> INSTAGRAM
                normalized.contains("facebook.com") ||
                    normalized.contains("fb.watch") ||
                    normalized.contains("fb.com") -> FACEBOOK
                normalized.contains("tiktok.com") -> TIKTOK
                else -> null
            }
        }
    }
}
