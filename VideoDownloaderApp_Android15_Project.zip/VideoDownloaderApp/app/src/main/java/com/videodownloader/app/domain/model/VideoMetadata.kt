package com.videodownloader.app.domain.model

data class VideoMetadata(
    val sourceUrl: String,
    val platform: SupportedPlatform,
    val title: String,
    val thumbnailUrl: String?,
    val durationSeconds: Long,
    val qualities: List<VideoQualityOption>
)
