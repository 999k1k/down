package com.videodownloader.app.domain.model

data class DownloadItem(
    val id: String,
    val sourceUrl: String,
    val platform: SupportedPlatform,
    val title: String,
    val thumbnailUrl: String?,
    val qualityLabel: String,
    val formatSelector: String,
    val status: DownloadStatus,
    val progress: Int,
    val speedText: String,
    val etaSeconds: Long,
    val fileSizeBytes: Long,
    val mediaStoreUri: String?,
    val errorCode: String?,
    val createdAtMillis: Long
) {
    val isActive: Boolean
        get() = status == DownloadStatus.QUEUED ||
            status == DownloadStatus.DOWNLOADING ||
            status == DownloadStatus.MERGING
}
