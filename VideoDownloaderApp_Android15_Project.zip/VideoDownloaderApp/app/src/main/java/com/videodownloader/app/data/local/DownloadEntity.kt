package com.videodownloader.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.videodownloader.app.domain.model.DownloadItem
import com.videodownloader.app.domain.model.DownloadStatus
import com.videodownloader.app.domain.model.SupportedPlatform

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val sourceUrl: String,
    val platform: String,
    val title: String,
    val thumbnailUrl: String?,
    val qualityLabel: String,
    val formatSelector: String,
    val status: String,
    val progress: Int,
    val speedText: String,
    val etaSeconds: Long,
    val fileSizeBytes: Long,
    val mediaStoreUri: String?,
    val errorCode: String?,
    val createdAtMillis: Long
) {
    fun toDomain(): DownloadItem = DownloadItem(
        id = id,
        sourceUrl = sourceUrl,
        platform = runCatching { SupportedPlatform.valueOf(platform) }
            .getOrDefault(SupportedPlatform.INSTAGRAM),
        title = title,
        thumbnailUrl = thumbnailUrl,
        qualityLabel = qualityLabel,
        formatSelector = formatSelector,
        status = runCatching { DownloadStatus.valueOf(status) }
            .getOrDefault(DownloadStatus.FAILED),
        progress = progress,
        speedText = speedText,
        etaSeconds = etaSeconds,
        fileSizeBytes = fileSizeBytes,
        mediaStoreUri = mediaStoreUri,
        errorCode = errorCode,
        createdAtMillis = createdAtMillis
    )
}
