package com.videodownloader.app.presentation.downloads

import com.videodownloader.app.domain.model.DownloadItem

data class DownloadsUiState(
    val activeDownloads: List<DownloadItem> = emptyList(),
    val finishedDownloads: List<DownloadItem> = emptyList()
) {
    val isEmpty: Boolean
        get() = activeDownloads.isEmpty() && finishedDownloads.isEmpty()
}
