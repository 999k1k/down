package com.videodownloader.app.data.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.videodownloader.app.MainActivity
import com.videodownloader.app.R
import com.videodownloader.app.data.engine.YoutubeDlEngine
import com.videodownloader.app.data.local.DownloadDao
import com.videodownloader.app.data.storage.MediaStoreVideoSaver
import com.videodownloader.app.domain.model.DownloadError
import com.videodownloader.app.domain.model.DownloadStatus
import com.videodownloader.app.domain.model.SupportedPlatform
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject

@AndroidEntryPoint
class VideoDownloadForegroundService : Service() {

    @Inject
    lateinit var downloadDao: DownloadDao

    @Inject
    lateinit var youtubeDlEngine: YoutubeDlEngine

    @Inject
    lateinit var mediaStoreVideoSaver: MediaStoreVideoSaver

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val notificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_DOWNLOAD -> {
                val downloadId = intent.getStringExtra(EXTRA_DOWNLOAD_ID) ?: return START_NOT_STICKY
                promoteToForeground(
                    title = getString(R.string.notif_downloading_title),
                    contentText = getString(R.string.status_queued),
                    progress = 0,
                    indeterminate = true,
                    downloadId = downloadId
                )
                launchDownloadJob(downloadId)
            }

            ACTION_CANCEL_DOWNLOAD -> {
                val downloadId = intent.getStringExtra(EXTRA_DOWNLOAD_ID)
                if (downloadId != null) {
                    cancelDownload(downloadId)
                }
            }
        }
        return START_NOT_STICKY
    }

    /**
     * Android 15 (API 35) enforces a 6-hour/24h quota on dataSync foreground services.
     * Handling onTimeout prevents RemoteServiceException crashes.
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        val runningIds = activeJobs.keys.toList()
        runningIds.forEach { id ->
            youtubeDlEngine.cancelProcess(id)
            activeJobs.remove(id)?.cancel()
        }
        serviceScope.launch {
            runningIds.forEach { id ->
                downloadDao.markFailedOrCancelled(
                    id = id,
                    status = DownloadStatus.FAILED.name,
                    errorCode = ERROR_TIMEOUT
                )
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
    }

    private fun launchDownloadJob(downloadId: String) {
        if (activeJobs.containsKey(downloadId)) return

        val job = serviceScope.launch {
            val entity = downloadDao.getById(downloadId)
            if (entity == null) {
                finishIfIdle()
                return@launch
            }

            val platform = runCatching { SupportedPlatform.valueOf(entity.platform) }
                .getOrDefault(SupportedPlatform.INSTAGRAM)

            var lastUpdateMillis = 0L

            try {
                downloadDao.updateProgress(
                    id = downloadId,
                    status = DownloadStatus.DOWNLOADING.name,
                    progress = 0,
                    speedText = "",
                    etaSeconds = 0L
                )

                val downloadResult = youtubeDlEngine.downloadToTempMp4(
                    processId = downloadId,
                    sourceUrl = entity.sourceUrl,
                    platform = platform,
                    formatSelector = entity.formatSelector
                ) { percent, speedText, etaSeconds, isMerging ->
                    val now = System.currentTimeMillis()
                    if (isMerging || now - lastUpdateMillis >= 400L) {
                        lastUpdateMillis = now
                        val status = if (isMerging) DownloadStatus.MERGING else DownloadStatus.DOWNLOADING
                        serviceScope.launch {
                            downloadDao.updateProgress(
                                id = downloadId,
                                status = status.name,
                                progress = percent,
                                speedText = speedText,
                                etaSeconds = etaSeconds
                            )
                        }
                        val subText = if (isMerging) {
                            getString(R.string.notif_merging_text)
                        } else {
                            buildString {
                                append("$percent%")
                                if (speedText.isNotBlank()) append(" • $speedText")
                            }
                        }
                        updateNotification(
                            title = entity.title,
                            contentText = subText,
                            progress = percent,
                            indeterminate = isMerging,
                            downloadId = downloadId
                        )
                    }
                }

                val tempFile = downloadResult.getOrElse { error ->
                    val errorCode = errorToCode(error)
                    downloadDao.markFailedOrCancelled(
                        id = downloadId,
                        status = DownloadStatus.FAILED.name,
                        errorCode = errorCode
                    )
                    showCompletionNotification(
                        notificationId = downloadId.hashCode(),
                        title = getString(R.string.notif_failed_title),
                        text = entity.title
                    )
                    return@launch
                }

                val savedResult = mediaStoreVideoSaver.saveMp4ToMovies(
                    sourceFile = tempFile,
                    displayTitle = entity.title
                )

                savedResult.fold(
                    onSuccess = { (uri, fileSize) ->
                        downloadDao.markCompleted(
                            id = downloadId,
                            status = DownloadStatus.COMPLETED.name,
                            fileSizeBytes = fileSize,
                            mediaStoreUri = uri.toString()
                        )
                        showCompletionNotification(
                            notificationId = downloadId.hashCode(),
                            title = getString(R.string.notif_completed_title),
                            text = entity.title
                        )
                    },
                    onFailure = {
                        downloadDao.markFailedOrCancelled(
                            id = downloadId,
                            status = DownloadStatus.FAILED.name,
                            errorCode = ERROR_STORAGE
                        )
                        showCompletionNotification(
                            notificationId = downloadId.hashCode(),
                            title = getString(R.string.notif_failed_title),
                            text = entity.title
                        )
                    }
                )
            } catch (_: CancellationException) {
                downloadDao.markFailedOrCancelled(
                    id = downloadId,
                    status = DownloadStatus.CANCELLED.name,
                    errorCode = null
                )
            } finally {
                activeJobs.remove(downloadId)
                finishIfIdle()
            }
        }

        activeJobs[downloadId] = job
    }

    private fun cancelDownload(downloadId: String) {
        youtubeDlEngine.cancelProcess(downloadId)
        activeJobs.remove(downloadId)?.cancel()
        serviceScope.launch {
            downloadDao.markFailedOrCancelled(
                id = downloadId,
                status = DownloadStatus.CANCELLED.name,
                errorCode = null
            )
            finishIfIdle()
        }
    }

    private fun finishIfIdle() {
        if (activeJobs.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun promoteToForeground(
        title: String,
        contentText: String,
        progress: Int,
        indeterminate: Boolean,
        downloadId: String
    ) {
        val notification = buildProgressNotification(
            title = title,
            contentText = contentText,
            progress = progress,
            indeterminate = indeterminate,
            downloadId = downloadId
        )
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
            0
        }
        ServiceCompat.startForeground(this, FOREGROUND_NOTIFICATION_ID, notification, fgsType)
    }

    private fun updateNotification(
        title: String,
        contentText: String,
        progress: Int,
        indeterminate: Boolean,
        downloadId: String
    ) {
        val notification = buildProgressNotification(
            title = title,
            contentText = contentText,
            progress = progress,
            indeterminate = indeterminate,
            downloadId = downloadId
        )
        notificationManager.notify(FOREGROUND_NOTIFICATION_ID, notification)
    }

    private fun buildProgressNotification(
        title: String,
        contentText: String,
        progress: Int,
        indeterminate: Boolean,
        downloadId: String
    ): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val cancelIntent = PendingIntent.getService(
            this,
            downloadId.hashCode(),
            Intent(this, VideoDownloadForegroundService::class.java).apply {
                action = ACTION_CANCEL_DOWNLOAD
                putExtra(EXTRA_DOWNLOAD_ID, downloadId)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download_notification)
            .setContentTitle(title)
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress, indeterminate)
            .setContentIntent(openAppIntent)
            .addAction(0, getString(R.string.action_cancel), cancelIntent)
            .build()
    }

    private fun showCompletionNotification(notificationId: Int, title: String, text: String) {
        val openAppIntent = PendingIntent.getActivity(
            this,
            notificationId,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()
        notificationManager.notify(notificationId, notification)
    }

    private fun errorToCode(error: Throwable): String = when (error) {
        is DownloadError.NoInternet -> ERROR_NO_INTERNET
        is DownloadError.PrivateOrRestricted -> ERROR_PRIVATE
        is DownloadError.VideoNotFound -> ERROR_NOT_FOUND
        is DownloadError.StorageFailed -> ERROR_STORAGE
        is DownloadError.ServiceTimeout -> ERROR_TIMEOUT
        else -> ERROR_UNKNOWN
    }

    override fun onDestroy() {
        activeJobs.keys.forEach { youtubeDlEngine.cancelProcess(it) }
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "video_downloads_channel"
        const val FOREGROUND_NOTIFICATION_ID = 1001
        const val ACTION_START_DOWNLOAD = "com.videodownloader.app.action.START_DOWNLOAD"
        const val ACTION_CANCEL_DOWNLOAD = "com.videodownloader.app.action.CANCEL_DOWNLOAD"
        const val EXTRA_DOWNLOAD_ID = "extra_download_id"

        const val ERROR_NO_INTERNET = "NO_INTERNET"
        const val ERROR_PRIVATE = "PRIVATE"
        const val ERROR_NOT_FOUND = "NOT_FOUND"
        const val ERROR_STORAGE = "STORAGE"
        const val ERROR_TIMEOUT = "TIMEOUT"
        const val ERROR_UNKNOWN = "UNKNOWN"

        fun createStartIntent(context: Context, downloadId: String): Intent =
            Intent(context, VideoDownloadForegroundService::class.java).apply {
                action = ACTION_START_DOWNLOAD
                putExtra(EXTRA_DOWNLOAD_ID, downloadId)
            }

        fun createCancelIntent(context: Context, downloadId: String): Intent =
            Intent(context, VideoDownloadForegroundService::class.java).apply {
                action = ACTION_CANCEL_DOWNLOAD
                putExtra(EXTRA_DOWNLOAD_ID, downloadId)
            }
    }
}
