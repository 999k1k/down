package com.videodownloader.app.presentation.downloads

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.videodownloader.app.R
import com.videodownloader.app.data.service.VideoDownloadForegroundService
import com.videodownloader.app.domain.model.DownloadItem
import com.videodownloader.app.domain.model.DownloadStatus

@Composable
fun DownloadsScreen(
    onShowMessage: (String) -> Unit,
    viewModel: DownloadsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    if (state.isEmpty) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.DownloadDone,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = stringResource(R.string.empty_downloads_title),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = stringResource(R.string.empty_downloads_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (state.activeDownloads.isNotEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.section_active),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            items(state.activeDownloads, key = { it.id }) { item ->
                ActiveDownloadCard(
                    item = item,
                    onCancel = { viewModel.cancelDownload(item.id) }
                )
            }
        }

        if (state.finishedDownloads.isNotEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.section_completed),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            items(state.finishedDownloads, key = { it.id }) { item ->
                FinishedDownloadCard(
                    item = item,
                    onPlay = { openVideoPlayer(context, item.mediaStoreUri, onShowMessage) },
                    onShare = { shareVideo(context, item.mediaStoreUri, item.title, onShowMessage) },
                    onDelete = { viewModel.deleteDownload(item.id) }
                )
            }
        }
    }
}

@Composable
private fun ActiveDownloadCard(
    item: DownloadItem,
    onCancel: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${item.platform.displayName} • ${item.qualityLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onCancel) {
                    Icon(
                        imageVector = Icons.Rounded.Cancel,
                        contentDescription = stringResource(R.string.action_cancel),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            if (item.status == DownloadStatus.QUEUED || item.status == DownloadStatus.MERGING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            } else {
                LinearProgressIndicator(
                    progress = { item.progress / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val statusLabel = when (item.status) {
                    DownloadStatus.QUEUED -> stringResource(R.string.status_queued)
                    DownloadStatus.MERGING -> stringResource(R.string.status_merging)
                    else -> "${item.progress}%"
                }
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelMedium
                )
                if (item.speedText.isNotBlank()) {
                    Text(
                        text = item.speedText,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun FinishedDownloadCard(
    item: DownloadItem,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!item.thumbnailUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(width = 84.dp, height = 56.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    val sizePart = if (item.fileSizeBytes > 0L) {
                        " • ${Formatter.formatShortFileSize(context, item.fileSizeBytes)}"
                    } else {
                        ""
                    }
                    Text(
                        text = "${item.platform.displayName} • ${item.qualityLabel}$sizePart",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val statusText = when (item.status) {
                        DownloadStatus.COMPLETED -> stringResource(R.string.status_completed)
                        DownloadStatus.CANCELLED -> stringResource(R.string.status_cancelled)
                        else -> mapErrorCode(item.errorCode)
                    }
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (item.status == DownloadStatus.COMPLETED) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.error
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (item.status == DownloadStatus.COMPLETED && !item.mediaStoreUri.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = onPlay,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.action_play))
                    }
                    OutlinedButton(
                        onClick = onShare,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.action_share))
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = stringResource(R.string.action_delete),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun mapErrorCode(code: String?): String = when (code) {
    VideoDownloadForegroundService.ERROR_NO_INTERNET -> stringResource(R.string.error_no_internet)
    VideoDownloadForegroundService.ERROR_PRIVATE -> stringResource(R.string.error_private_video)
    VideoDownloadForegroundService.ERROR_NOT_FOUND -> stringResource(R.string.error_not_found)
    VideoDownloadForegroundService.ERROR_STORAGE -> stringResource(R.string.error_storage_failed)
    VideoDownloadForegroundService.ERROR_TIMEOUT -> stringResource(R.string.error_timeout)
    else -> stringResource(R.string.status_failed)
}

private fun openVideoPlayer(
    context: Context,
    uriString: String?,
    onShowMessage: (String) -> Unit
) {
    if (uriString.isNullOrBlank()) {
        onShowMessage(context.getString(R.string.file_unavailable))
        return
    }
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(Uri.parse(uriString), "video/mp4")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(intent) }
        .onFailure { onShowMessage(context.getString(R.string.no_video_player_found)) }
}

private fun shareVideo(
    context: Context,
    uriString: String?,
    title: String,
    onShowMessage: (String) -> Unit
) {
    if (uriString.isNullOrBlank()) {
        onShowMessage(context.getString(R.string.file_unavailable))
        return
    }
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
        putExtra(Intent.EXTRA_SUBJECT, title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser = Intent.createChooser(shareIntent, context.getString(R.string.share_video_chooser))
    runCatching { context.startActivity(chooser) }
        .onFailure { onShowMessage(context.getString(R.string.file_unavailable)) }
}
