package com.videodownloader.app.domain.repository

import com.videodownloader.app.domain.model.DownloadItem
import com.videodownloader.app.domain.model.VideoMetadata
import com.videodownloader.app.domain.model.VideoQualityOption
import kotlinx.coroutines.flow.Flow

interface VideoDownloadRepository {
    suspend fun extractVideoMetadata(url: String): Result<VideoMetadata>
    suspend fun enqueueDownload(metadata: VideoMetadata, quality: VideoQualityOption): Result<String>
    suspend fun cancelDownload(downloadId: String)
    suspend fun deleteDownload(downloadId: String): Boolean
    fun observeDownloads(): Flow<List<DownloadItem>>
}
