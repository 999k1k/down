package com.videodownloader.app.domain.usecase

import com.videodownloader.app.domain.model.DownloadError
import com.videodownloader.app.domain.model.SupportedPlatform
import com.videodownloader.app.domain.model.VideoMetadata
import com.videodownloader.app.domain.repository.VideoDownloadRepository
import javax.inject.Inject

class ValidateAndExtractVideoUseCase @Inject constructor(
    private val repository: VideoDownloadRepository
) {
    suspend operator fun invoke(rawUrl: String): Result<VideoMetadata> {
        val cleaned = rawUrl.trim()
        if (cleaned.isEmpty()) {
            return Result.failure(DownloadError.EmptyUrl)
        }
        if (SupportedPlatform.detect(cleaned) == null) {
            return Result.failure(DownloadError.UnsupportedPlatform)
        }
        return repository.extractVideoMetadata(cleaned)
    }
}
