package com.videodownloader.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.util.Log
import com.videodownloader.app.data.engine.YoutubeDlEngine
import com.videodownloader.app.data.service.VideoDownloadForegroundService
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class VideoDownloaderApp : Application() {

    @Inject
    lateinit var youtubeDlEngine: YoutubeDlEngine

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        createDownloadNotificationChannel()
        appScope.launch {
            runCatching { youtubeDlEngine.initialize() }
                .onFailure { Log.e(TAG, "Failed to initialize yt-dlp/FFmpeg engine", it) }
        }
    }

    private fun createDownloadNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                VideoDownloadForegroundService.CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "VideoDownloaderApp"
    }
}
