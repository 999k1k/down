package com.videodownloader.app.presentation.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.videodownloader.app.domain.usecase.CancelDownloadUseCase
import com.videodownloader.app.domain.usecase.DeleteDownloadUseCase
import com.videodownloader.app.domain.usecase.ObserveDownloadsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    observeDownloadsUseCase: ObserveDownloadsUseCase,
    private val cancelDownloadUseCase: CancelDownloadUseCase,
    private val deleteDownloadUseCase: DeleteDownloadUseCase
) : ViewModel() {

    val uiState: StateFlow<DownloadsUiState> = observeDownloadsUseCase()
        .map { items ->
            val (active, finished) = items.partition { it.isActive }
            DownloadsUiState(
                activeDownloads = active,
                finishedDownloads = finished
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = DownloadsUiState()
        )

    fun cancelDownload(downloadId: String) {
        viewModelScope.launch {
            cancelDownloadUseCase(downloadId)
        }
    }

    fun deleteDownload(downloadId: String) {
        viewModelScope.launch {
            deleteDownloadUseCase(downloadId)
        }
    }
}
