package com.videodownloader.app.di

import android.content.Context
import androidx.room.Room
import com.videodownloader.app.data.local.AppDatabase
import com.videodownloader.app.data.local.DownloadDao
import com.videodownloader.app.data.repository.VideoDownloadRepositoryImpl
import com.videodownloader.app.domain.repository.VideoDownloadRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "video_downloader.db"
        ).fallbackToDestructiveMigration().build()

    @Provides
    fun provideDownloadDao(database: AppDatabase): DownloadDao = database.downloadDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindVideoDownloadRepository(
        impl: VideoDownloadRepositoryImpl
    ): VideoDownloadRepository
}
