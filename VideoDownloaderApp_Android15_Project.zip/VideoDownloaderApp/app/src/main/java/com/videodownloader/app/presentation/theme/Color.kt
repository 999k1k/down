package com.videodownloader.app.presentation.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF1A56DB)
val OnPrimaryWhite = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDCE6FF)
val OnPrimaryContainerLight = Color(0xFF001945)

val SecondaryTeal = Color(0xFF0F766E)
val SecondaryContainerLight = Color(0xFFCCFBF1)
val OnSecondaryContainerLight = Color(0xFF042F2E)

val PrimaryBlueDark = Color(0xFFAEC6FF)
val OnPrimaryDark = Color(0xFF002E6E)
val PrimaryContainerDark = Color(0xFF00439B)
val OnPrimaryContainerDark = Color(0xFFDCE6FF)

val SecondaryTealDark = Color(0xFF5EEAD4)
val SecondaryContainerDark = Color(0xFF115E59)
val OnSecondaryContainerDark = Color(0xFFCCFBF1)
