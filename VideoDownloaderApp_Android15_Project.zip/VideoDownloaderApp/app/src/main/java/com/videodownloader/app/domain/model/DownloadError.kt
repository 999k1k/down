package com.videodownloader.app.domain.model

sealed class DownloadError : Exception() {
    data object EmptyUrl : DownloadError()
    data object UnsupportedPlatform : DownloadError()
    data object NoInternet : DownloadError()
    data object PrivateOrRestricted : DownloadError()
    data object VideoNotFound : DownloadError()
    data object EngineNotReady : DownloadError()
    data object StorageFailed : DownloadError()
    data object ServiceTimeout : DownloadError()
    data class Unknown(val details: String?) : DownloadError()
}
