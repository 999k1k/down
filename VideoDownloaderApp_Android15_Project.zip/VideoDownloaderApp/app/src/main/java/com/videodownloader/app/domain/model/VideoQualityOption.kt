package com.videodownloader.app.domain.model

data class VideoQualityOption(
    val id: String,
    val label: String,
    val height: Int,
    val formatSelector: String,
    val estimatedSizeBytes: Long?,
    val isWatermarkFree: Boolean = false
)
