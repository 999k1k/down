package com.videodownloader.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadEntity)

    @Query(
        "UPDATE downloads SET status = :status, progress = :progress, speedText = :speedText, etaSeconds = :etaSeconds WHERE id = :id"
    )
    suspend fun updateProgress(
        id: String,
        status: String,
        progress: Int,
        speedText: String,
        etaSeconds: Long
    )

    @Query(
        "UPDATE downloads SET status = :status, progress = 100, speedText = '', etaSeconds = 0, fileSizeBytes = :fileSizeBytes, mediaStoreUri = :mediaStoreUri, errorCode = NULL WHERE id = :id"
    )
    suspend fun markCompleted(
        id: String,
        status: String,
        fileSizeBytes: Long,
        mediaStoreUri: String
    )

    @Query(
        "UPDATE downloads SET status = :status, speedText = '', etaSeconds = 0, errorCode = :errorCode WHERE id = :id"
    )
    suspend fun markFailedOrCancelled(
        id: String,
        status: String,
        errorCode: String?
    )

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: String)
}
