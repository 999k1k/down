package com.videodownloader.app.domain.usecase

import com.videodownloader.app.domain.repository.VideoDownloadRepository
import javax.inject.Inject

class DeleteDownloadUseCase @Inject constructor(
    private val repository: VideoDownloadRepository
) {
    suspend operator fun invoke(downloadId: String): Boolean = repository.deleteDownload(downloadId)
}
