package com.videodownloader.app.domain.usecase

import com.videodownloader.app.domain.model.DownloadItem
import com.videodownloader.app.domain.repository.VideoDownloadRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ObserveDownloadsUseCase @Inject constructor(
    private val repository: VideoDownloadRepository
) {
    operator fun invoke(): Flow<List<DownloadItem>> = repository.observeDownloads()
}
