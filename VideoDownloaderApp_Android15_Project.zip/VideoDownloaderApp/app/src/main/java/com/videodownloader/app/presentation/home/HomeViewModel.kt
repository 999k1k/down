package com.videodownloader.app.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.videodownloader.app.R
import com.videodownloader.app.domain.model.DownloadError
import com.videodownloader.app.domain.model.VideoQualityOption
import com.videodownloader.app.domain.usecase.StartVideoDownloadUseCase
import com.videodownloader.app.domain.usecase.ValidateAndExtractVideoUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val validateAndExtractVideoUseCase: ValidateAndExtractVideoUseCase,
    private val startVideoDownloadUseCase: StartVideoDownloadUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    fun onUrlChanged(newUrl: String) {
        _uiState.update {
            it.copy(urlInput = newUrl, errorMessageRes = null)
        }
    }

    fun clearUrl() {
        _uiState.update {
            it.copy(
                urlInput = "",
                errorMessageRes = null,
                extractedVideo = null,
                showQualitySheet = false
            )
        }
    }

    fun analyzeLink() {
        val currentUrl = _uiState.value.urlInput
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAnalyzing = true,
                    errorMessageRes = null,
                    showQualitySheet = false
                )
            }

            validateAndExtractVideoUseCase(currentUrl).fold(
                onSuccess = { metadata ->
                    _uiState.update {
                        it.copy(
                            isAnalyzing = false,
                            extractedVideo = metadata,
                            showQualitySheet = true,
                            errorMessageRes = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isAnalyzing = false,
                            errorMessageRes = mapErrorToStringRes(error)
                        )
                    }
                }
            )
        }
    }

    fun openQualitySheet() {
        if (_uiState.value.extractedVideo != null) {
            _uiState.update { it.copy(showQualitySheet = true) }
        }
    }

    fun dismissQualitySheet() {
        _uiState.update { it.copy(showQualitySheet = false) }
    }

    fun startDownload(quality: VideoQualityOption) {
        val metadata = _uiState.value.extractedVideo ?: return
        viewModelScope.launch {
            startVideoDownloadUseCase(metadata, quality).fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            showQualitySheet = false,
                            downloadStartedEvent = true
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            showQualitySheet = false,
                            errorMessageRes = mapErrorToStringRes(error)
                        )
                    }
                }
            )
        }
    }

    fun onDownloadStartedConsumed() {
        _uiState.update { it.copy(downloadStartedEvent = false) }
    }

    private fun mapErrorToStringRes(error: Throwable): Int = when (error) {
        is DownloadError.EmptyUrl -> R.string.error_empty_url
        is DownloadError.UnsupportedPlatform -> R.string.error_unsupported_platform
        is DownloadError.NoInternet -> R.string.error_no_internet
        is DownloadError.PrivateOrRestricted -> R.string.error_private_video
        is DownloadError.VideoNotFound -> R.string.error_not_found
        is DownloadError.EngineNotReady -> R.string.error_engine_not_ready
        is DownloadError.StorageFailed -> R.string.error_storage_failed
        is DownloadError.ServiceTimeout -> R.string.error_timeout
        else -> R.string.error_unknown
    }
}
