package com.videodownloader.app.data.repository

import android.content.Context
import androidx.core.content.ContextCompat
import com.videodownloader.app.data.engine.YoutubeDlEngine
import com.videodownloader.app.data.local.DownloadDao
import com.videodownloader.app.data.local.DownloadEntity
import com.videodownloader.app.data.service.VideoDownloadForegroundService
import com.videodownloader.app.data.storage.MediaStoreVideoSaver
import com.videodownloader.app.domain.model.DownloadError
import com.videodownloader.app.domain.model.DownloadItem
import com.videodownloader.app.domain.model.DownloadStatus
import com.videodownloader.app.domain.model.SupportedPlatform
import com.videodownloader.app.domain.model.VideoMetadata
import com.videodownloader.app.domain.model.VideoQualityOption
import com.videodownloader.app.domain.repository.VideoDownloadRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VideoDownloadRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val youtubeDlEngine: YoutubeDlEngine,
    private val downloadDao: DownloadDao,
    private val mediaStoreVideoSaver: MediaStoreVideoSaver
) : VideoDownloadRepository {

    override suspend fun extractVideoMetadata(url: String): Result<VideoMetadata> {
        val platform = SupportedPlatform.detect(url)
            ?: return Result.failure(DownloadError.UnsupportedPlatform)
        return youtubeDlEngine.extractMetadata(url, platform)
    }

    override suspend fun enqueueDownload(
        metadata: VideoMetadata,
        quality: VideoQualityOption
    ): Result<String> = runCatching {
        val id = UUID.randomUUID().toString()
        val entity = DownloadEntity(
            id = id,
            sourceUrl = metadata.sourceUrl,
            platform = metadata.platform.name,
            title = metadata.title,
            thumbnailUrl = metadata.thumbnailUrl,
            qualityLabel = quality.label,
            formatSelector = quality.formatSelector,
            status = DownloadStatus.QUEUED.name,
            progress = 0,
            speedText = "",
            etaSeconds = 0L,
            fileSizeBytes = quality.estimatedSizeBytes ?: 0L,
            mediaStoreUri = null,
            errorCode = null,
            createdAtMillis = System.currentTimeMillis()
        )
        downloadDao.upsert(entity)

        val intent = VideoDownloadForegroundService.createStartIntent(context, id)
        ContextCompat.startForegroundService(context, intent)
        id
    }

    override suspend fun cancelDownload(downloadId: String) {
        youtubeDlEngine.cancelProcess(downloadId)
        val cancelIntent = VideoDownloadForegroundService.createCancelIntent(context, downloadId)
        runCatching { context.startService(cancelIntent) }
        downloadDao.markFailedOrCancelled(
            id = downloadId,
            status = DownloadStatus.CANCELLED.name,
            errorCode = null
        )
    }

    override suspend fun deleteDownload(downloadId: String): Boolean {
        val existing = downloadDao.getById(downloadId) ?: return false
        if (existing.status == DownloadStatus.DOWNLOADING.name ||
            existing.status == DownloadStatus.QUEUED.name ||
            existing.status == DownloadStatus.MERGING.name
        ) {
            cancelDownload(downloadId)
        }
        val deletedFromStorage = mediaStoreVideoSaver.deleteVideoByUri(existing.mediaStoreUri)
        downloadDao.deleteById(downloadId)
        return deletedFromStorage
    }

    override fun observeDownloads(): Flow<List<DownloadItem>> =
        downloadDao.observeAll().map { entities -> entities.map { it.toDomain() } }
}
