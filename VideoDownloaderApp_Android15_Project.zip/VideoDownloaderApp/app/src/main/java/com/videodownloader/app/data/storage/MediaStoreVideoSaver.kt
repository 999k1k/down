package com.videodownloader.app.data.storage

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaStoreVideoSaver @Inject constructor(
    @ApplicationContext private val context: Context
) {
    suspend fun saveMp4ToMovies(
        sourceFile: File,
        displayTitle: String
    ): Result<Pair<Uri, Long>> = withContext(Dispatchers.IO) {
        runCatching {
            require(sourceFile.exists() && sourceFile.length() > 0L) {
                "Temporary MP4 file does not exist or is empty"
            }

            val safeName = sanitizeFileName(displayTitle)
            val fileName = "${safeName}_${System.currentTimeMillis()}.mp4"
            val fileSize = sourceFile.length()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_MOVIES}/VideoDownloader"
                    )
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val collection = MediaStore.Video.Media.getContentUri(
                    MediaStore.VOLUME_EXTERNAL_PRIMARY
                )
                val itemUri = resolver.insert(collection, values)
                    ?: error("Failed to create MediaStore entry")

                try {
                    resolver.openOutputStream(itemUri)?.use { output ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(output, bufferSize = DEFAULT_BUFFER_SIZE * 4)
                        }
                    } ?: error("Failed to open MediaStore output stream")

                    val publishValues = ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }
                    resolver.update(itemUri, publishValues, null, null)
                } catch (t: Throwable) {
                    resolver.delete(itemUri, null, null)
                    throw t
                } finally {
                    sourceFile.delete()
                }
                itemUri to fileSize
            } else {
                @Suppress("DEPRECATION")
                val moviesDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "VideoDownloader"
                )
                if (!moviesDir.exists()) moviesDir.mkdirs()
                val destFile = File(moviesDir, fileName)
                sourceFile.copyTo(destFile, overwrite = true)
                sourceFile.delete()
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destFile.absolutePath),
                    arrayOf("video/mp4"),
                    null
                )
                Uri.fromFile(destFile) to fileSize
            }
        }
    }

    suspend fun deleteVideoByUri(uriString: String?): Boolean = withContext(Dispatchers.IO) {
        if (uriString.isNullOrBlank()) return@withContext true
        runCatching {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "file") {
                val file = File(uri.path ?: return@runCatching true)
                !file.exists() || file.delete()
            } else {
                context.contentResolver.delete(uri, null, null) >= 0
            }
        }.getOrDefault(false)
    }

    private fun sanitizeFileName(raw: String): String {
        val cleaned = raw
            .replace(Regex("[\\/:*?"<>|\n\r]+"), "_")
            .trim()
            .take(64)
        return cleaned.ifEmpty { "video" }
    }
}
