package com.videodownloader.app.presentation.home

import androidx.annotation.StringRes
import com.videodownloader.app.domain.model.VideoMetadata

data class HomeUiState(
    val urlInput: String = "",
    val isAnalyzing: Boolean = false,
    val extractedVideo: VideoMetadata? = null,
    val showQualitySheet: Boolean = false,
    @StringRes val errorMessageRes: Int? = null,
    val downloadStartedEvent: Boolean = false
)
