package com.videodownloader.app.data.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.videodownloader.app.domain.model.DownloadError
import com.videodownloader.app.domain.model.SupportedPlatform
import com.videodownloader.app.domain.model.VideoMetadata
import com.videodownloader.app.domain.model.VideoQualityOption
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoFormat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YoutubeDlEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val initMutex = Mutex()
    @Volatile
    private var initialized = false

    suspend fun initialize() {
        if (initialized) return
        initMutex.withLock {
            if (initialized) return
            withContext(Dispatchers.IO) {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                initialized = true
            }
        }
    }

    suspend fun extractMetadata(
        url: String,
        platform: SupportedPlatform
    ): Result<VideoMetadata> = withContext(Dispatchers.IO) {
        if (!hasInternetConnection()) {
            return@withContext Result.failure(DownloadError.NoInternet)
        }
        try {
            initialize()
        } catch (_: Throwable) {
            return@withContext Result.failure(DownloadError.EngineNotReady)
        }

        try {
            val request = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--no-warnings")
                addOption("--socket-timeout", "20")
                if (platform == SupportedPlatform.TIKTOK) {
                    addOption("--extractor-args", "tiktok:api_hostname=api22-normal-c-useast2a.tiktokv.com")
                }
            }

            val info = YoutubeDL.getInstance().getInfo(request)
            val duration = info.duration.toLong().coerceAtLeast(0L)
            val title = info.title?.takeIf { it.isNotBlank() } ?: "${platform.displayName} Video"
            val qualities = buildQualityOptions(
                formats = info.formats.orEmpty(),
                durationSeconds = duration,
                platform = platform
            )

            Result.success(
                VideoMetadata(
                    sourceUrl = url,
                    platform = platform,
                    title = title,
                    thumbnailUrl = info.thumbnail,
                    durationSeconds = duration,
                    qualities = qualities
                )
            )
        } catch (t: Throwable) {
            Result.failure(mapException(t))
        }
    }

    suspend fun downloadToTempMp4(
        processId: String,
        sourceUrl: String,
        platform: SupportedPlatform,
        formatSelector: String,
        onProgress: (percent: Int, speedText: String, etaSeconds: Long, isMerging: Boolean) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        if (!hasInternetConnection()) {
            return@withContext Result.failure(DownloadError.NoInternet)
        }
        try {
            initialize()
        } catch (_: Throwable) {
            return@withContext Result.failure(DownloadError.EngineNotReady)
        }

        val workDir = File(context.cacheDir, "dl_$processId").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        try {
            val outputTemplate = File(workDir, "video.%(ext)s").absolutePath
            val request = YoutubeDLRequest(sourceUrl).apply {
                addOption("-f", formatSelector)
                addOption("--merge-output-format", "mp4")
                addOption("--remux-video", "mp4")
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--newline")
                addOption("-o", outputTemplate)
                if (platform == SupportedPlatform.TIKTOK) {
                    addOption("--extractor-args", "tiktok:api_hostname=api22-normal-c-useast2a.tiktokv.com")
                }
            }

            YoutubeDL.getInstance().execute(request, processId) { progress, etaInSeconds, line ->
                val isMerging = line.contains("[Merger]", ignoreCase = true) ||
                    line.contains("[VideoRemuxer]", ignoreCase = true) ||
                    line.contains("Merging formats", ignoreCase = true)
                val speed = parseSpeed(line)
                val clampedProgress = when {
                    isMerging -> 99
                    progress < 0f -> 0
                    else -> progress.toInt().coerceIn(0, 99)
                }
                onProgress(clampedProgress, speed, etaInSeconds.coerceAtLeast(0L), isMerging)
            }

            val outputFile = workDir.listFiles()
                ?.firstOrNull { it.isFile && it.extension.equals("mp4", ignoreCase = true) && it.length() > 0L }
                ?: workDir.listFiles()?.maxByOrNull { it.length() }
                ?: return@withContext Result.failure(DownloadError.StorageFailed)

            Result.success(outputFile)
        } catch (t: Throwable) {
            workDir.deleteRecursively()
            Result.failure(mapException(t))
        }
    }

    fun cancelProcess(processId: String) {
        runCatching {
            YoutubeDL.getInstance().destroyProcessById(processId)
        }
        File(context.cacheDir, "dl_$processId").deleteRecursively()
    }

    private fun buildQualityOptions(
        formats: List<VideoFormat>,
        durationSeconds: Long,
        platform: SupportedPlatform
    ): List<VideoQualityOption> {
        val videoFormats = formats.filter { fmt ->
            val hasVideo = fmt.vcodec != null && fmt.vcodec != "none"
            val hasHeight = fmt.height > 0
            hasVideo && hasHeight
        }

        val audioSizeEstimate = formats
            .filter { it.vcodec == "none" && it.acodec != null && it.acodec != "none" }
            .maxByOrNull { it.tbr }
            ?.let { estimateFormatBytes(it, durationSeconds) }
            ?: 0L

        val buckets = listOf(1080, 720, 480, 360)
        val result = mutableListOf<VideoQualityOption>()

        for (targetHeight in buckets) {
            val candidates = videoFormats.filter { fmt ->
                val lowerBound = when (targetHeight) {
                    1080 -> 900
                    720 -> 600
                    480 -> 400
                    else -> 240
                }
                val upperBound = when (targetHeight) {
                    1080 -> 1440
                    720 -> 899
                    480 -> 599
                    else -> 399
                }
                fmt.height in lowerBound..upperBound
            }

            val bestCandidate = candidates
                .sortedWith(
                    compareByDescending<VideoFormat> {
                        platform == SupportedPlatform.TIKTOK && isLikelyWatermarkFree(it)
                    }.thenByDescending { it.ext.equals("mp4", ignoreCase = true) }
                        .thenByDescending { it.tbr }
                )
                .firstOrNull()

            if (bestCandidate != null) {
                val videoBytes = estimateFormatBytes(bestCandidate, durationSeconds)
                val needsAudioMerge = bestCandidate.acodec == null || bestCandidate.acodec == "none"
                val totalEstimated = videoBytes?.let { v ->
                    if (needsAudioMerge) v + audioSizeEstimate else v
                }

                val watermarkFree = platform == SupportedPlatform.TIKTOK && isLikelyWatermarkFree(bestCandidate)
                val selector = if (platform == SupportedPlatform.TIKTOK && watermarkFree && !bestCandidate.formatId.isNullOrBlank()) {
                    "${bestCandidate.formatId}+bestaudio[ext=m4a]/${bestCandidate.formatId}/best[height<=$targetHeight][ext=mp4]/best[height<=$targetHeight]"
                } else {
                    "bestvideo[height<=$targetHeight][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=$targetHeight]+bestaudio/best[height<=$targetHeight][ext=mp4]/best[height<=$targetHeight]"
                }

                result.add(
                    VideoQualityOption(
                        id = "mp4_${targetHeight}p",
                        label = "${targetHeight}p MP4",
                        height = targetHeight,
                        formatSelector = selector,
                        estimatedSizeBytes = totalEstimated,
                        isWatermarkFree = watermarkFree
                    )
                )
            }
        }

        if (result.isEmpty()) {
            val bestFormat = videoFormats.maxByOrNull { it.height }
            val fallbackHeight = bestFormat?.height?.takeIf { it > 0 } ?: 720
            val watermarkFree = platform == SupportedPlatform.TIKTOK &&
                (bestFormat == null || isLikelyWatermarkFree(bestFormat))
            result.add(
                VideoQualityOption(
                    id = "mp4_best",
                    label = "${fallbackHeight}p MP4",
                    height = fallbackHeight,
                    formatSelector = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
                    estimatedSizeBytes = bestFormat?.let { estimateFormatBytes(it, durationSeconds) },
                    isWatermarkFree = watermarkFree
                )
            )
        }

        return result
    }

    private fun isLikelyWatermarkFree(format: VideoFormat): Boolean {
        val id = format.formatId.orEmpty().lowercase()
        val note = format.formatNote.orEmpty().lowercase()
        return !id.contains("watermark") && !note.contains("watermark")
    }

    private fun estimateFormatBytes(format: VideoFormat, durationSeconds: Long): Long? {
        if (format.fileSize > 0L) return format.fileSize
        if (format.fileSizeApproximate > 0L) return format.fileSizeApproximate
        if (format.tbr > 0 && durationSeconds > 0L) {
            return ((format.tbr * 1000.0 / 8.0) * durationSeconds).toLong()
        }
        return null
    }

    private fun parseSpeed(line: String): String {
        val match = SPEED_REGEX.find(line)
        return match?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    private fun hasInternetConnection(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun mapException(t: Throwable): DownloadError {
        val msg = t.message.orEmpty().lowercase()
        return when {
            msg.contains("unable to resolve host") ||
                msg.contains("temporary failure in name resolution") ||
                msg.contains("network is unreachable") ||
                msg.contains("timed out") -> DownloadError.NoInternet

            msg.contains("private") ||
                msg.contains("login required") ||
                msg.contains("sign in") ||
                msg.contains("cookies") ||
                msg.contains("403") ||
                msg.contains("age-restricted") -> DownloadError.PrivateOrRestricted

            msg.contains("404") ||
                msg.contains("not found") ||
                msg.contains("video unavailable") ||
                msg.contains("removed") -> DownloadError.VideoNotFound

            msg.contains("unsupported url") -> DownloadError.UnsupportedPlatform

            else -> DownloadError.Unknown(t.message)
        }
    }

    companion object {
        private val SPEED_REGEX = Regex("at\s+([0-9.]+\s*[KMG]?i?B/s)", RegexOption.IGNORE_CASE)
    }
}
