package com.videodownloader.app.domain.usecase

import com.videodownloader.app.domain.model.VideoMetadata
import com.videodownloader.app.domain.model.VideoQualityOption
import com.videodownloader.app.domain.repository.VideoDownloadRepository
import javax.inject.Inject

class StartVideoDownloadUseCase @Inject constructor(
    private val repository: VideoDownloadRepository
) {
    suspend operator fun invoke(
        metadata: VideoMetadata,
        quality: VideoQualityOption
    ): Result<String> = repository.enqueueDownload(metadata, quality)
}
